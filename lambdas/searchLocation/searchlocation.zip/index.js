const fetch = require("node-fetch");

exports.handler = async (event) => {
  if (event.httpMethod === "GET") {
    return await getLocations();
  } else {
    return httpMethodError();
  }
};

const getLocations = async (event) => {
  const key = process.env.LOCATION_API_KEY;
  const lat = event.queryStringParameters.lat;
  const lon = event.queryStringParameters.lon;

  console.log(`GET location for ${lat} ${lon}`);
  const result = await fetch(
    `https://us1.locationiq.com/v1/reverse.php?key=${key}&lat=${lat}&lon=${lon}&format=json`
  );
  const data = await result.json();
  const response = {
    statusCode: 200,
    body: data,
  };
  return response;
};

const httpMethodError = () => {
  const response = {
    statusCode: 405,
    body: JSON.stringify("Only GET request is supported"),
  };
  return response;
};
